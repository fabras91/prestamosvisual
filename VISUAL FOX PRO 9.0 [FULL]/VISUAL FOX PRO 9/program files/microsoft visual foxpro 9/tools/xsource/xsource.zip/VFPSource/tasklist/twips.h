#ifndef __TWIPS_H
#define __TWIPS_H

#define WU_LOGPIXELSX 	88
#define WU_LOGPIXELSY 	90

#define TWIPS_PER_INCH 	1440

#define AXIS_X 			0
#define AXIS_Y 			1

#endif