#DEFINE PG1ED1A_LOC	"Which fields do you want on your form?" + chr(13) + chr(10)
#DEFINE PG1ED1B_LOC	"Each field you select will become a new control on your form."
#DEFINE PG2ED1A_LOC	"Select a style for the controls you want to add."
	
