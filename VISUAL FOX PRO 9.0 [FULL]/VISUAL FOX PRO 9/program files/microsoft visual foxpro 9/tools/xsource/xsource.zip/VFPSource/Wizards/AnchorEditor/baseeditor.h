#include FoxPro.H
#include BaseEditorEnglish.H

#define ccCR							chr(13)
	* Carriage return
