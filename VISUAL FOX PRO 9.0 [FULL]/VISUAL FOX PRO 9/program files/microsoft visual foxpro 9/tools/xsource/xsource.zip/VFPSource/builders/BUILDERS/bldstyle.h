* Header file for AutoStyle builder

#DEFINE PG1LBL1_LOC			"Which style do you want for the selected controls?" + CHR(13) + CHR(10) + ;
							"To apply the style to your form, click apply now."
#DEFINE PG1VALUE1_LOC		"Text Box"
#DEFINE PG1VALUE2_LOC		"Combo Box"

#DEFINE NOTBLCREATE_LOC		"The Styles table CTRLSTYL.DBF was not found, and the default table was not successfully created."

