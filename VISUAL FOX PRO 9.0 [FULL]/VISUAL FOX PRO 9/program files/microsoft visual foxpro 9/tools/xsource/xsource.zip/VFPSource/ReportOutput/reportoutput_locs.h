* locs for REPORTOUTPUT.APP

#DEFINE OUTPUTAPP_APPNAME_LOC    "VFP Report Output Application"

#DEFINE OUTPUTAPP_CONFIGTABLEBROWSE_LOC    "Output Configuration Table"

#DEFINE OUTPUTAPP_CONFIGTABLEWRONG_LOC     "Configuration table specified to " + ;
                                           OUTPUTAPP_APPNAME_LOC + CHR(13) + ;
                                           "is not found or is in the wrong format." 

#DEFINE OUTPUTAPP_UNKNOWN_ERROR_LOC       "An unknown error has occurred in " + OUTPUTAPP_APPNAME_LOC
   
