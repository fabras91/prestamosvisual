#include FOXPRO.H

* Messages.

#define ccLOC_NO_OBJECT					'You must select an object before running this builder.'
#define ccLOC_INVALID_CODE				'The code to be inserted is invalid. The error message was:' + ccCR + ccCR + '<insert>'

* Other constants

#define ccCRLF							chr(13) + chr(10)
#define ccCR							chr(13)
#define ccLF							chr(10)
#define ccTAB							chr(9)
