*- migdb4.h
*-
*-
#DEFINE lbl_type 11
#DEFINE scr_type 18
#DEFINE frm_type 7

#DEFINE C_ERRDB3FILE	105	&& Not a dBASE IV file.  FoxPro converts dBASE III FRMs and LBLs natively.
#DEFINE C_ERRBADDB4		106	&& Not a DBASE IV file (the file has the wrong header for dBASE IV).

#DEFINE C_ERRFTYPE_LOC	"Incorrect file ID type for a dBASE IV .SCR or .LBL file."
#DEFINE C_ERRNOFMT_LOC	"Unable to locate dBASE III format (.FMT) file."

